const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Post = require('../models/Post');

router.get('/', (req, res) => {
  res.render('index');
});

router.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.render('users/list', { users });
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/users/create', (req, res) => {
  res.render('users/create');
});

router.post('/users/create', async (req, res) => {
  try {
    const newUser = new User(req.body);
    await newUser.save();
    res.redirect('/users');
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/users/delete/:id', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.redirect('/users');
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/users/edit/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).send('User not found');
    }
    res.render('users/edit', { user });
  } catch (error) {
    res.status(500).send(error.toString());
  }
});

router.post('/users/edit/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      email: req.body.email,
      password: req.body.password,
      picturePath: req.body.picturePath,
      location: req.body.location,
      occupation: req.body.occupation,
      viewedProfile: req.body.viewedProfile,
      impressions: req.body.impressions,
    };

    await User.findByIdAndUpdate(id, updateData, { new: false });
    res.redirect('/users');
  } catch (error) {
    res.status(500).send(error.toString());
  }
});

// Posts routes
router.get('/posts', async (req, res) => {
  try {
    const posts = await Post.find();
    res.render('posts/list', { posts });
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/posts/create', (req, res) => {
  res.render('posts/create');
});

router.post('/posts/create', async (req, res) => {
  try {
    const newPost = new Post(req.body);
    await newPost.save();
    res.redirect('/posts');
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/posts/delete/:id', async (req, res) => {
  try {
    await Post.findByIdAndDelete(req.params.id);
    res.redirect('/posts');
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/posts/edit/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).send('Post not found');
    }
    res.render('posts/edit', { post });
  } catch (error) {
    res.status(500).send(error.toString());
  }
});

router.post('/posts/edit/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = {
      userId: req.body.userId,
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      location: req.body.location,
      description: req.body.description,
      picturePath: req.body.picturePath,
      userPicturePath: req.body.userPicturePath,
      // Add other fields as needed
    };

    await Post.findByIdAndUpdate(id, updateData, { new: false });
    res.redirect('/posts');
  } catch (error) {
    res.status(500).send(error.toString());
  }
});

module.exports = router;

