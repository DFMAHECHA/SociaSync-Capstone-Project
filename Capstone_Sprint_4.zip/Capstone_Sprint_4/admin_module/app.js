const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();
const app = express();

// Import routes
const router = require('./routes/routes');

//import db data
const User = require('./models/User');
const Post = require('./models/Post');
const { users, posts } = require('./data');

// EJS Configuration
app.set('view engine', 'ejs');

// Middleware for parsing JSON and urlencoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from 'public' directory
app.use(express.static('public'));

// MongoDB Connection
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('Could not connect to MongoDB', err));

mongoose.connection.once('open', async () => {
  console.log('Connected to MongoDB');

  // Insert Users if collection is empty
  const userCount = await User.countDocuments();
  if (userCount === 0) {
    User.insertMany(users)
      .then(() => console.log('Users data inserted successfully'))
      .catch((error) => console.error('Error inserting users data:', error));
  }

  // Insert Posts if collection is empty
  const postCount = await Post.countDocuments();
  if (postCount === 0) {
    Post.insertMany(posts)
      .then(() => console.log('Posts data inserted successfully'))
      .catch((error) => console.error('Error inserting posts data:', error));
  }
});

// Use Routes
app.use('/', router);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
